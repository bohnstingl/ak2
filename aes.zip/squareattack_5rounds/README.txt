Usage of the squareattack 5 rounds
1.) cmake .
2.) make
3.) ./squareattack_5rounds

The executable will now perform a square attack on 5 rounds AES